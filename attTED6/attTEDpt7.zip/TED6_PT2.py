for i in range(1, 11):
    print("tabuada: ", i)
    for k in range (1, 11):
        print(i, "*", k, "=", i*k)