n = int(input("Digite um numero: "))
for k in range(1, 11):
    print(f"{n * k} = {n * k}")