amigos = ['jão', "pedro", 'maria', "carla"]

for amigo in amigos:
    print("ola {}, como vc vai?". format(amigos))