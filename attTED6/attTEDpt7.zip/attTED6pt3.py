amigos =[ 'jão', 'pedro', 'maria']

for amigo in amigos:
    print(amigos)