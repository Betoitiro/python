n = 1000

while n <= 2000:
    if n % 11 ==5:
        print(n)
    n +=1

for n in range(1001,2002):
    if n % 11 ==5:
        print(n)
